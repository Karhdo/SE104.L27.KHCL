﻿namespace PhanMemQLTV
{
    partial class frmQLSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQLSach));
            this.grpTTSach = new System.Windows.Forms.GroupBox();
            this.lblNhapNgaySinh = new System.Windows.Forms.Label();
            this.dtmNgNhapSach = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.lblNhapTinhTrang = new System.Windows.Forms.Label();
            this.lblNhapSLNhap = new System.Windows.Forms.Label();
            this.lblNhapCD = new System.Windows.Forms.Label();
            this.lblNhapSLCon = new System.Windows.Forms.Label();
            this.lblNhapTriGia = new System.Windows.Forms.Label();
            this.lblNhapTenNXB = new System.Windows.Forms.Label();
            this.lblNhapTenTG = new System.Windows.Forms.Label();
            this.lblNhapTenSach = new System.Windows.Forms.Label();
            this.cboTinhTrang = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTriGia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSLNhap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTheLoai = new System.Windows.Forms.TextBox();
            this.txtNamXB = new System.Windows.Forms.TextBox();
            this.txtNXB = new System.Windows.Forms.TextBox();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewDSSach = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.grpTimKiem = new System.Windows.Forms.GroupBox();
            this.txtNDTimKiem = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radTenCD = new System.Windows.Forms.RadioButton();
            this.radTenTG = new System.Windows.Forms.RadioButton();
            this.radTenSach = new System.Windows.Forms.RadioButton();
            this.radMaSach = new System.Windows.Forms.RadioButton();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnLoadDS = new System.Windows.Forms.Button();
            this.errTenSach = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTG = new System.Windows.Forms.ErrorProvider(this.components);
            this.errNXB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errNamXB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errCD = new System.Windows.Forms.ErrorProvider(this.components);
            this.errSLNhap = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTriGia = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTinhTrang = new System.Windows.Forms.ErrorProvider(this.components);
            this.colMaSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayNhapSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenTG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaNXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNamXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTriGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpTTSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSSach)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpTimKiem.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTenSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNamXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTriGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang)).BeginInit();
            this.SuspendLayout();
            // 
            // grpTTSach
            // 
            this.grpTTSach.Controls.Add(this.lblNhapNgaySinh);
            this.grpTTSach.Controls.Add(this.dtmNgNhapSach);
            this.grpTTSach.Controls.Add(this.label11);
            this.grpTTSach.Controls.Add(this.lblNhapTinhTrang);
            this.grpTTSach.Controls.Add(this.lblNhapSLNhap);
            this.grpTTSach.Controls.Add(this.lblNhapCD);
            this.grpTTSach.Controls.Add(this.lblNhapSLCon);
            this.grpTTSach.Controls.Add(this.lblNhapTriGia);
            this.grpTTSach.Controls.Add(this.lblNhapTenNXB);
            this.grpTTSach.Controls.Add(this.lblNhapTenTG);
            this.grpTTSach.Controls.Add(this.lblNhapTenSach);
            this.grpTTSach.Controls.Add(this.cboTinhTrang);
            this.grpTTSach.Controls.Add(this.label8);
            this.grpTTSach.Controls.Add(this.txtGhiChu);
            this.grpTTSach.Controls.Add(this.label9);
            this.grpTTSach.Controls.Add(this.txtTriGia);
            this.grpTTSach.Controls.Add(this.label7);
            this.grpTTSach.Controls.Add(this.txtSLNhap);
            this.grpTTSach.Controls.Add(this.label6);
            this.grpTTSach.Controls.Add(this.label5);
            this.grpTTSach.Controls.Add(this.label10);
            this.grpTTSach.Controls.Add(this.label4);
            this.grpTTSach.Controls.Add(this.label3);
            this.grpTTSach.Controls.Add(this.txtTheLoai);
            this.grpTTSach.Controls.Add(this.txtNamXB);
            this.grpTTSach.Controls.Add(this.txtNXB);
            this.grpTTSach.Controls.Add(this.txtTacGia);
            this.grpTTSach.Controls.Add(this.txtTenSach);
            this.grpTTSach.Controls.Add(this.label2);
            this.grpTTSach.Controls.Add(this.txtMaSach);
            this.grpTTSach.Controls.Add(this.label1);
            this.grpTTSach.Location = new System.Drawing.Point(19, 158);
            this.grpTTSach.Name = "grpTTSach";
            this.grpTTSach.Size = new System.Drawing.Size(713, 216);
            this.grpTTSach.TabIndex = 2;
            this.grpTTSach.TabStop = false;
            this.grpTTSach.Text = "Thông tin Sách";
            // 
            // lblNhapNgaySinh
            // 
            this.lblNhapNgaySinh.AutoSize = true;
            this.lblNhapNgaySinh.Location = new System.Drawing.Point(317, 35);
            this.lblNhapNgaySinh.Name = "lblNhapNgaySinh";
            this.lblNhapNgaySinh.Size = new System.Drawing.Size(0, 19);
            this.lblNhapNgaySinh.TabIndex = 13;
            // 
            // dtmNgNhapSach
            // 
            this.dtmNgNhapSach.CustomFormat = "dd/MM/yyyy";
            this.dtmNgNhapSach.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmNgNhapSach.Location = new System.Drawing.Point(346, 22);
            this.dtmNgNhapSach.Name = "dtmNgNhapSach";
            this.dtmNgNhapSach.Size = new System.Drawing.Size(169, 27);
            this.dtmNgNhapSach.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(240, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 19);
            this.label11.TabIndex = 11;
            this.label11.Text = "Ngày nhập sách :";
            // 
            // lblNhapTinhTrang
            // 
            this.lblNhapTinhTrang.AutoSize = true;
            this.lblNhapTinhTrang.Location = new System.Drawing.Point(463, 148);
            this.lblNhapTinhTrang.Name = "lblNhapTinhTrang";
            this.lblNhapTinhTrang.Size = new System.Drawing.Size(0, 19);
            this.lblNhapTinhTrang.TabIndex = 10;
            // 
            // lblNhapSLNhap
            // 
            this.lblNhapSLNhap.AutoSize = true;
            this.lblNhapSLNhap.Location = new System.Drawing.Point(523, 90);
            this.lblNhapSLNhap.Name = "lblNhapSLNhap";
            this.lblNhapSLNhap.Size = new System.Drawing.Size(0, 19);
            this.lblNhapSLNhap.TabIndex = 10;
            // 
            // lblNhapCD
            // 
            this.lblNhapCD.AutoSize = true;
            this.lblNhapCD.Location = new System.Drawing.Point(463, 58);
            this.lblNhapCD.Name = "lblNhapCD";
            this.lblNhapCD.Size = new System.Drawing.Size(0, 19);
            this.lblNhapCD.TabIndex = 10;
            // 
            // lblNhapSLCon
            // 
            this.lblNhapSLCon.AutoSize = true;
            this.lblNhapSLCon.Location = new System.Drawing.Point(463, 88);
            this.lblNhapSLCon.Name = "lblNhapSLCon";
            this.lblNhapSLCon.Size = new System.Drawing.Size(0, 19);
            this.lblNhapSLCon.TabIndex = 10;
            // 
            // lblNhapTriGia
            // 
            this.lblNhapTriGia.AutoSize = true;
            this.lblNhapTriGia.Location = new System.Drawing.Point(463, 119);
            this.lblNhapTriGia.Name = "lblNhapTriGia";
            this.lblNhapTriGia.Size = new System.Drawing.Size(0, 19);
            this.lblNhapTriGia.TabIndex = 10;
            // 
            // lblNhapTenNXB
            // 
            this.lblNhapTenNXB.AutoSize = true;
            this.lblNhapTenNXB.Location = new System.Drawing.Point(117, 151);
            this.lblNhapTenNXB.Name = "lblNhapTenNXB";
            this.lblNhapTenNXB.Size = new System.Drawing.Size(0, 19);
            this.lblNhapTenNXB.TabIndex = 10;
            // 
            // lblNhapTenTG
            // 
            this.lblNhapTenTG.AutoSize = true;
            this.lblNhapTenTG.Location = new System.Drawing.Point(117, 120);
            this.lblNhapTenTG.Name = "lblNhapTenTG";
            this.lblNhapTenTG.Size = new System.Drawing.Size(0, 19);
            this.lblNhapTenTG.TabIndex = 10;
            // 
            // lblNhapTenSach
            // 
            this.lblNhapTenSach.AutoSize = true;
            this.lblNhapTenSach.Location = new System.Drawing.Point(117, 90);
            this.lblNhapTenSach.Name = "lblNhapTenSach";
            this.lblNhapTenSach.Size = new System.Drawing.Size(0, 19);
            this.lblNhapTenSach.TabIndex = 9;
            // 
            // cboTinhTrang
            // 
            this.cboTinhTrang.FormattingEnabled = true;
            this.cboTinhTrang.Items.AddRange(new object[] {
            "Mới",
            "Cũ"});
            this.cboTinhTrang.Location = new System.Drawing.Point(463, 147);
            this.cboTinhTrang.Name = "cboTinhTrang";
            this.cboTinhTrang.Size = new System.Drawing.Size(198, 27);
            this.cboTinhTrang.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(379, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tình Trạng :";
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(463, 174);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(198, 27);
            this.txtGhiChu.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(379, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 19);
            this.label9.TabIndex = 0;
            this.label9.Text = "Ghi Chú:";
            // 
            // txtTriGia
            // 
            this.txtTriGia.Location = new System.Drawing.Point(463, 116);
            this.txtTriGia.Name = "txtTriGia";
            this.txtTriGia.Size = new System.Drawing.Size(198, 27);
            this.txtTriGia.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(379, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "Trị Giá:";
            // 
            // txtSLNhap
            // 
            this.txtSLNhap.Location = new System.Drawing.Point(463, 85);
            this.txtSLNhap.Name = "txtSLNhap";
            this.txtSLNhap.Size = new System.Drawing.Size(198, 27);
            this.txtSLNhap.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(379, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "SL Nhập:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(379, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Thể loại:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 178);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "Năm XB :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "NXB:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tác Giả:";
            // 
            // txtTheLoai
            // 
            this.txtTheLoai.Location = new System.Drawing.Point(463, 55);
            this.txtTheLoai.Name = "txtTheLoai";
            this.txtTheLoai.Size = new System.Drawing.Size(198, 27);
            this.txtTheLoai.TabIndex = 1;
            // 
            // txtNamXB
            // 
            this.txtNamXB.Location = new System.Drawing.Point(114, 175);
            this.txtNamXB.Name = "txtNamXB";
            this.txtNamXB.Size = new System.Drawing.Size(196, 27);
            this.txtNamXB.TabIndex = 1;
            // 
            // txtNXB
            // 
            this.txtNXB.Location = new System.Drawing.Point(114, 145);
            this.txtNXB.Name = "txtNXB";
            this.txtNXB.Size = new System.Drawing.Size(196, 27);
            this.txtNXB.TabIndex = 1;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(114, 115);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(196, 27);
            this.txtTacGia.TabIndex = 1;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(114, 85);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(196, 27);
            this.txtTenSach.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên Sách :";
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(114, 56);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(196, 27);
            this.txtMaSach.TabIndex = 0;
            this.txtMaSach.TextChanged += new System.EventHandler(this.txtMaSach_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Sách :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dataGridViewDSSach
            // 
            this.dataGridViewDSSach.AllowUserToAddRows = false;
            this.dataGridViewDSSach.AllowUserToDeleteRows = false;
            this.dataGridViewDSSach.AllowUserToResizeRows = false;
            this.dataGridViewDSSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSSach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaSach,
            this.colNgayNhapSach,
            this.colTenSach,
            this.colTenLoai,
            this.colTenTG,
            this.colMaNXB,
            this.colNamXB,
            this.colSoLuong,
            this.colTriGia,
            this.colTinhTrang,
            this.colGhiChu});
            this.dataGridViewDSSach.Location = new System.Drawing.Point(6, 20);
            this.dataGridViewDSSach.Name = "dataGridViewDSSach";
            this.dataGridViewDSSach.RowHeadersWidth = 62;
            this.dataGridViewDSSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSSach.Size = new System.Drawing.Size(707, 183);
            this.dataGridViewDSSach.TabIndex = 2;
            this.dataGridViewDSSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSSach_CellClick);
            this.dataGridViewDSSach.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSSach_RowEnter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewDSSach);
            this.groupBox2.Location = new System.Drawing.Point(19, 431);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(719, 208);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách Sách";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.grpTimKiem);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(19, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(713, 97);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm Sách";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // grpTimKiem
            // 
            this.grpTimKiem.Controls.Add(this.txtNDTimKiem);
            this.grpTimKiem.Location = new System.Drawing.Point(435, 19);
            this.grpTimKiem.Name = "grpTimKiem";
            this.grpTimKiem.Size = new System.Drawing.Size(243, 60);
            this.grpTimKiem.TabIndex = 1;
            this.grpTimKiem.TabStop = false;
            this.grpTimKiem.Text = "Nhập thông tin cần Tìm Kiếm";
            // 
            // txtNDTimKiem
            // 
            this.txtNDTimKiem.Location = new System.Drawing.Point(11, 24);
            this.txtNDTimKiem.Name = "txtNDTimKiem";
            this.txtNDTimKiem.Size = new System.Drawing.Size(218, 27);
            this.txtNDTimKiem.TabIndex = 0;
            this.txtNDTimKiem.TextChanged += new System.EventHandler(this.txtNDTimKiem_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radTenCD);
            this.groupBox4.Controls.Add(this.radTenTG);
            this.groupBox4.Controls.Add(this.radTenSach);
            this.groupBox4.Controls.Add(this.radMaSach);
            this.groupBox4.Location = new System.Drawing.Point(31, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(376, 60);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm Theo";
            // 
            // radTenCD
            // 
            this.radTenCD.AutoSize = true;
            this.radTenCD.Location = new System.Drawing.Point(296, 24);
            this.radTenCD.Name = "radTenCD";
            this.radTenCD.Size = new System.Drawing.Size(82, 23);
            this.radTenCD.TabIndex = 3;
            this.radTenCD.TabStop = true;
            this.radTenCD.Text = "Tên CD";
            this.radTenCD.UseVisualStyleBackColor = true;
            // 
            // radTenTG
            // 
            this.radTenTG.AutoSize = true;
            this.radTenTG.Location = new System.Drawing.Point(208, 24);
            this.radTenTG.Name = "radTenTG";
            this.radTenTG.Size = new System.Drawing.Size(80, 23);
            this.radTenTG.TabIndex = 2;
            this.radTenTG.TabStop = true;
            this.radTenTG.Text = "Tên TG";
            this.radTenTG.UseVisualStyleBackColor = true;
            // 
            // radTenSach
            // 
            this.radTenSach.AutoSize = true;
            this.radTenSach.Location = new System.Drawing.Point(111, 24);
            this.radTenSach.Name = "radTenSach";
            this.radTenSach.Size = new System.Drawing.Size(91, 23);
            this.radTenSach.TabIndex = 1;
            this.radTenSach.TabStop = true;
            this.radTenSach.Text = "Tên Sách";
            this.radTenSach.UseVisualStyleBackColor = true;
            // 
            // radMaSach
            // 
            this.radMaSach.AutoSize = true;
            this.radMaSach.Location = new System.Drawing.Point(18, 24);
            this.radMaSach.Name = "radMaSach";
            this.radMaSach.Size = new System.Drawing.Size(88, 23);
            this.radMaSach.TabIndex = 0;
            this.radMaSach.TabStop = true;
            this.radMaSach.Text = "Mã Sách";
            this.radMaSach.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnThoat.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat.Image")));
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(272, 114);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(87, 39);
            this.btnThoat.TabIndex = 8;
            this.btnThoat.Text = "Home";
            this.btnThoat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy.Image")));
            this.btnHuy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy.Location = new System.Drawing.Point(522, 380);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(85, 39);
            this.btnHuy.TabIndex = 7;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu.Image")));
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(431, 380);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(85, 39);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa.Image")));
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(340, 380);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(85, 39);
            this.btnXoa.TabIndex = 5;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Image = ((System.Drawing.Image)(resources.GetObject("btnSua.Image")));
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(249, 380);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(85, 39);
            this.btnSua.TabIndex = 4;
            this.btnSua.Text = "Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThem
            // 
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(158, 380);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(85, 39);
            this.btnThem.TabIndex = 3;
            this.btnThem.Text = "Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnLoadDS
            // 
            this.btnLoadDS.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadDS.Image")));
            this.btnLoadDS.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadDS.Location = new System.Drawing.Point(365, 114);
            this.btnLoadDS.Name = "btnLoadDS";
            this.btnLoadDS.Size = new System.Drawing.Size(145, 39);
            this.btnLoadDS.TabIndex = 1;
            this.btnLoadDS.Text = "Load Danh Sách";
            this.btnLoadDS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadDS.UseVisualStyleBackColor = true;
            this.btnLoadDS.Click += new System.EventHandler(this.btnLoadDS_Click);
            // 
            // errTenSach
            // 
            this.errTenSach.ContainerControl = this;
            // 
            // errTG
            // 
            this.errTG.ContainerControl = this;
            // 
            // errNXB
            // 
            this.errNXB.ContainerControl = this;
            // 
            // errNamXB
            // 
            this.errNamXB.ContainerControl = this;
            // 
            // errCD
            // 
            this.errCD.ContainerControl = this;
            // 
            // errSLNhap
            // 
            this.errSLNhap.ContainerControl = this;
            // 
            // errTriGia
            // 
            this.errTriGia.ContainerControl = this;
            // 
            // errTinhTrang
            // 
            this.errTinhTrang.ContainerControl = this;
            // 
            // colMaSach
            // 
            this.colMaSach.DataPropertyName = "MaSach";
            this.colMaSach.HeaderText = "Mã Sách";
            this.colMaSach.MinimumWidth = 8;
            this.colMaSach.Name = "colMaSach";
            this.colMaSach.ReadOnly = true;
            this.colMaSach.Width = 60;
            // 
            // colNgayNhapSach
            // 
            this.colNgayNhapSach.DataPropertyName = "NgNhapSach";
            this.colNgayNhapSach.HeaderText = "Ngày Nhập";
            this.colNgayNhapSach.MinimumWidth = 6;
            this.colNgayNhapSach.Name = "colNgayNhapSach";
            this.colNgayNhapSach.Width = 125;
            // 
            // colTenSach
            // 
            this.colTenSach.DataPropertyName = "TenSach";
            this.colTenSach.HeaderText = "Tên Sách";
            this.colTenSach.MinimumWidth = 8;
            this.colTenSach.Name = "colTenSach";
            this.colTenSach.ReadOnly = true;
            this.colTenSach.Width = 140;
            // 
            // colTenLoai
            // 
            this.colTenLoai.DataPropertyName = "TheLoai";
            this.colTenLoai.HeaderText = "Thể loại";
            this.colTenLoai.MinimumWidth = 8;
            this.colTenLoai.Name = "colTenLoai";
            this.colTenLoai.ReadOnly = true;
            this.colTenLoai.Width = 80;
            // 
            // colTenTG
            // 
            this.colTenTG.DataPropertyName = "TacGia";
            this.colTenTG.HeaderText = "Tác Giả";
            this.colTenTG.MinimumWidth = 8;
            this.colTenTG.Name = "colTenTG";
            this.colTenTG.ReadOnly = true;
            this.colTenTG.Width = 150;
            // 
            // colMaNXB
            // 
            this.colMaNXB.DataPropertyName = "NXB";
            this.colMaNXB.HeaderText = "NXB";
            this.colMaNXB.MinimumWidth = 8;
            this.colMaNXB.Name = "colMaNXB";
            this.colMaNXB.ReadOnly = true;
            this.colMaNXB.Width = 150;
            // 
            // colNamXB
            // 
            this.colNamXB.DataPropertyName = "NamXB";
            this.colNamXB.HeaderText = "Năm XB";
            this.colNamXB.MinimumWidth = 8;
            this.colNamXB.Name = "colNamXB";
            this.colNamXB.Width = 150;
            // 
            // colSoLuong
            // 
            this.colSoLuong.DataPropertyName = "SLNhap";
            this.colSoLuong.HeaderText = "SL Nhập";
            this.colSoLuong.MinimumWidth = 8;
            this.colSoLuong.Name = "colSoLuong";
            this.colSoLuong.ReadOnly = true;
            this.colSoLuong.Width = 50;
            // 
            // colTriGia
            // 
            this.colTriGia.DataPropertyName = "TriGia";
            this.colTriGia.HeaderText = "Đơn Giá";
            this.colTriGia.MinimumWidth = 8;
            this.colTriGia.Name = "colTriGia";
            this.colTriGia.ReadOnly = true;
            this.colTriGia.Width = 60;
            // 
            // colTinhTrang
            // 
            this.colTinhTrang.DataPropertyName = "TinhTrang";
            this.colTinhTrang.HeaderText = "Tình Trạng";
            this.colTinhTrang.MinimumWidth = 8;
            this.colTinhTrang.Name = "colTinhTrang";
            this.colTinhTrang.ReadOnly = true;
            this.colTinhTrang.Width = 50;
            // 
            // colGhiChu
            // 
            this.colGhiChu.DataPropertyName = "GhiChu";
            this.colGhiChu.HeaderText = "Ghi Chú";
            this.colGhiChu.MinimumWidth = 8;
            this.colGhiChu.Name = "colGhiChu";
            this.colGhiChu.Width = 150;
            // 
            // frmQLSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(760, 647);
            this.Controls.Add(this.btnLoadDS);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.grpTTSach);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmQLSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sách";
            this.Load += new System.EventHandler(this.frmQLSach_Load);
            this.grpTTSach.ResumeLayout(false);
            this.grpTTSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSSach)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.grpTimKiem.ResumeLayout(false);
            this.grpTimKiem.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTenSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNamXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTriGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTTSach;
        private System.Windows.Forms.ComboBox cboTinhTrang;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTriGia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSLNhap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dataGridViewDSSach;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radTenSach;
        private System.Windows.Forms.RadioButton radMaSach;
        private System.Windows.Forms.GroupBox grpTimKiem;
        private System.Windows.Forms.TextBox txtNDTimKiem;
        private System.Windows.Forms.Button btnLoadDS;
        private System.Windows.Forms.RadioButton radTenCD;
        private System.Windows.Forms.RadioButton radTenTG;
        private System.Windows.Forms.Label lblNhapTenSach;
        private System.Windows.Forms.Label lblNhapTinhTrang;
        private System.Windows.Forms.Label lblNhapSLNhap;
        private System.Windows.Forms.Label lblNhapCD;
        private System.Windows.Forms.Label lblNhapSLCon;
        private System.Windows.Forms.Label lblNhapTriGia;
        private System.Windows.Forms.Label lblNhapTenNXB;
        private System.Windows.Forms.Label lblNhapTenTG;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTheLoai;
        private System.Windows.Forms.TextBox txtNamXB;
        private System.Windows.Forms.TextBox txtNXB;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.ErrorProvider errTenSach;
        private System.Windows.Forms.ErrorProvider errTG;
        private System.Windows.Forms.ErrorProvider errNXB;
        private System.Windows.Forms.ErrorProvider errNamXB;
        private System.Windows.Forms.ErrorProvider errCD;
        private System.Windows.Forms.ErrorProvider errSLNhap;
        private System.Windows.Forms.ErrorProvider errTriGia;
        private System.Windows.Forms.ErrorProvider errTinhTrang;
        private System.Windows.Forms.Label lblNhapNgaySinh;
        private System.Windows.Forms.DateTimePicker dtmNgNhapSach;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayNhapSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenTG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaNXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNamXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTriGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTinhTrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGhiChu;
    }
}