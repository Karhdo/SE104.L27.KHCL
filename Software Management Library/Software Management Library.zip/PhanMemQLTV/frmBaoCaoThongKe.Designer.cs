﻿namespace PhanMemQLTV
{
    partial class frmBaoCaoThongKe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBaoCaoThongKe));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSLSachQuaHan = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTongGiaTriSach = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSLCon = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSLMuon = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSLCuon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSLDauSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnXemSLSachQuaHan = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSLDGQuaHan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSLDGMuon = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSLDocGia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSLDGQuaHan = new System.Windows.Forms.Button();
            this.dataGridViewDSDGQuaHan = new System.Windows.Forms.DataGridView();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnBaocao = new System.Windows.Forms.Button();
            this.dtpBaocao = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSDGQuaHan)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSLSachQuaHan);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtTongGiaTriSach);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtSLCon);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtSLMuon);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtSLCuon);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtSLDauSach);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(19, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(576, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thống kê Sách";
            // 
            // txtSLSachQuaHan
            // 
            this.txtSLSachQuaHan.Location = new System.Drawing.Point(411, 83);
            this.txtSLSachQuaHan.Name = "txtSLSachQuaHan";
            this.txtSLSachQuaHan.Size = new System.Drawing.Size(148, 30);
            this.txtSLSachQuaHan.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(317, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 22);
            this.label10.TabIndex = 0;
            this.label10.Text = "SL quá hạn:";
            // 
            // txtTongGiaTriSach
            // 
            this.txtTongGiaTriSach.Location = new System.Drawing.Point(411, 54);
            this.txtTongGiaTriSach.Name = "txtTongGiaTriSach";
            this.txtTongGiaTriSach.Size = new System.Drawing.Size(148, 30);
            this.txtTongGiaTriSach.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(317, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 22);
            this.label12.TabIndex = 0;
            this.label12.Text = "Tổng giá trị:";
            // 
            // txtSLCon
            // 
            this.txtSLCon.Location = new System.Drawing.Point(411, 24);
            this.txtSLCon.Name = "txtSLCon";
            this.txtSLCon.Size = new System.Drawing.Size(148, 30);
            this.txtSLCon.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(317, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 22);
            this.label11.TabIndex = 0;
            this.label11.Text = "SL Còn:";
            // 
            // txtSLMuon
            // 
            this.txtSLMuon.Location = new System.Drawing.Point(122, 84);
            this.txtSLMuon.Name = "txtSLMuon";
            this.txtSLMuon.Size = new System.Drawing.Size(146, 30);
            this.txtSLMuon.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "SL Mượn:";
            // 
            // txtSLCuon
            // 
            this.txtSLCuon.Location = new System.Drawing.Point(122, 54);
            this.txtSLCuon.Name = "txtSLCuon";
            this.txtSLCuon.Size = new System.Drawing.Size(146, 30);
            this.txtSLCuon.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "SL Cuốn:";
            // 
            // txtSLDauSach
            // 
            this.txtSLDauSach.Location = new System.Drawing.Point(122, 24);
            this.txtSLDauSach.Name = "txtSLDauSach";
            this.txtSLDauSach.Size = new System.Drawing.Size(146, 30);
            this.txtSLDauSach.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "SL Đầu Sách:";
            // 
            // btnXemSLSachQuaHan
            // 
            this.btnXemSLSachQuaHan.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnXemSLSachQuaHan.Location = new System.Drawing.Point(247, 243);
            this.btnXemSLSachQuaHan.Name = "btnXemSLSachQuaHan";
            this.btnXemSLSachQuaHan.Size = new System.Drawing.Size(171, 39);
            this.btnXemSLSachQuaHan.TabIndex = 2;
            this.btnXemSLSachQuaHan.Text = "DS Sách Mượn Quá Hạn";
            this.btnXemSLSachQuaHan.UseVisualStyleBackColor = false;
            this.btnXemSLSachQuaHan.Click += new System.EventHandler(this.btnXemSLSachQuaHan_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.dtpBaocao);
            this.groupBox2.Controls.Add(this.txtSLDGQuaHan);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtSLDGMuon);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtSLDocGia);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(19, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(576, 94);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thống kê Độc Giả";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txtSLDGQuaHan
            // 
            this.txtSLDGQuaHan.Location = new System.Drawing.Point(419, 19);
            this.txtSLDGQuaHan.Name = "txtSLDGQuaHan";
            this.txtSLDGQuaHan.Size = new System.Drawing.Size(140, 30);
            this.txtSLDGQuaHan.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(309, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "SL ĐG Vi Phạm:";
            // 
            // txtSLDGMuon
            // 
            this.txtSLDGMuon.Location = new System.Drawing.Point(125, 52);
            this.txtSLDGMuon.Name = "txtSLDGMuon";
            this.txtSLDGMuon.Size = new System.Drawing.Size(143, 30);
            this.txtSLDGMuon.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "SL ĐG Đã Mượn:";
            // 
            // txtSLDocGia
            // 
            this.txtSLDocGia.Location = new System.Drawing.Point(125, 19);
            this.txtSLDocGia.Name = "txtSLDocGia";
            this.txtSLDocGia.Size = new System.Drawing.Size(143, 30);
            this.txtSLDocGia.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 22);
            this.label8.TabIndex = 0;
            this.label8.Text = "SL Độc Giả:";
            // 
            // btnSLDGQuaHan
            // 
            this.btnSLDGQuaHan.AutoSize = true;
            this.btnSLDGQuaHan.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSLDGQuaHan.Location = new System.Drawing.Point(424, 243);
            this.btnSLDGQuaHan.Name = "btnSLDGQuaHan";
            this.btnSLDGQuaHan.Size = new System.Drawing.Size(188, 39);
            this.btnSLDGQuaHan.TabIndex = 2;
            this.btnSLDGQuaHan.Text = "DS Độc Giả Vi Phạm";
            this.btnSLDGQuaHan.UseVisualStyleBackColor = false;
            this.btnSLDGQuaHan.Click += new System.EventHandler(this.btnSLDGQuaHan_Click);
            // 
            // dataGridViewDSDGQuaHan
            // 
            this.dataGridViewDSDGQuaHan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSDGQuaHan.Location = new System.Drawing.Point(7, 288);
            this.dataGridViewDSDGQuaHan.Name = "dataGridViewDSDGQuaHan";
            this.dataGridViewDSDGQuaHan.RowHeadersWidth = 62;
            this.dataGridViewDSDGQuaHan.Size = new System.Drawing.Size(605, 145);
            this.dataGridViewDSDGQuaHan.TabIndex = 2;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnHome.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(19, 242);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(88, 40);
            this.btnHome.TabIndex = 3;
            this.btnHome.Text = "Home";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnBaocao
            // 
            this.btnBaocao.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnBaocao.Location = new System.Drawing.Point(113, 243);
            this.btnBaocao.Name = "btnBaocao";
            this.btnBaocao.Size = new System.Drawing.Size(128, 39);
            this.btnBaocao.TabIndex = 2;
            this.btnBaocao.Text = "Báo cáo";
            this.btnBaocao.UseVisualStyleBackColor = false;
            this.btnBaocao.Click += new System.EventHandler(this.btnBaocao_Click);
            // 
            // dtpBaocao
            // 
            this.dtpBaocao.CustomFormat = "MM/yyyy";
            this.dtpBaocao.Enabled = false;
            this.dtpBaocao.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpBaocao.Location = new System.Drawing.Point(419, 55);
            this.dtpBaocao.Name = "dtpBaocao";
            this.dtpBaocao.ShowUpDown = true;
            this.dtpBaocao.Size = new System.Drawing.Size(140, 30);
            this.dtpBaocao.TabIndex = 2;
            this.dtpBaocao.ValueChanged += new System.EventHandler(this.dtpBaocao_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(309, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 22);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tháng báo cáo";
            // 
            // frmBaoCaoThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(624, 438);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnSLDGQuaHan);
            this.Controls.Add(this.btnBaocao);
            this.Controls.Add(this.btnXemSLSachQuaHan);
            this.Controls.Add(this.dataGridViewDSDGQuaHan);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Name = "frmBaoCaoThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Báo Cáo - Thống Kê";
            this.Load += new System.EventHandler(this.frmBaoCaoThongKe_Load);
            this.Click += new System.EventHandler(this.frmBaoCaoThongKe_Click);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSDGQuaHan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSLMuon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSLCuon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSLDauSach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSLDGMuon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSLDocGia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSLDGQuaHan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTongGiaTriSach;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSLCon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewDSDGQuaHan;
        private System.Windows.Forms.Button btnXemSLSachQuaHan;
        private System.Windows.Forms.TextBox txtSLSachQuaHan;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSLDGQuaHan;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnBaocao;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpBaocao;
    }
}