﻿namespace PhanMemQLTV
{
    partial class frmQLMuonTra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQLMuonTra));
            this.tabQLMuonTraSach = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.btnGiaHan = new System.Windows.Forms.Button();
            this.btnLoadDanhSach0 = new System.Windows.Forms.Button();
            this.btnNhap = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtTTMaSach = new System.Windows.Forms.TextBox();
            this.txtTTTenTG = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTTTenSach = new System.Windows.Forms.TextBox();
            this.txtTTSLCon = new System.Windows.Forms.TextBox();
            this.btnHuy0 = new System.Windows.Forms.Button();
            this.btnThoat0 = new System.Windows.Forms.Button();
            this.btnChoMuon0 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtNDTimKiem = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radMaSach = new System.Windows.Forms.RadioButton();
            this.radMaDG = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridViewDSMuon0 = new System.Windows.Forms.DataGridView();
            this.colMaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaDG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayMuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayTra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSLMuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboTinhTrang0 = new System.Windows.Forms.ComboBox();
            this.cboMaSach0 = new System.Windows.Forms.ComboBox();
            this.lblNhapSLNhap = new System.Windows.Forms.Label();
            this.txtMaPhieu0 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.dtmNgayMuon0 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.dtmNgayTra0 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.cboMaDG0 = new System.Windows.Forms.ComboBox();
            this.txtSLMuon0 = new System.Windows.Forms.TextBox();
            this.txtGhiChu0 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnLoadDS1 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtNDTimKiem1 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.radMaSach1 = new System.Windows.Forms.RadioButton();
            this.radMaDG1 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtTinhTrang1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtMaDG1 = new System.Windows.Forms.TextBox();
            this.txtMaPhieu1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dtmNgayMuon1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.dtmNgayTra1 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSLMuon1 = new System.Windows.Forms.TextBox();
            this.txtGhiChu1 = new System.Windows.Forms.TextBox();
            this.txtMaSach1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnThoat1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridViewDSMuon1 = new System.Windows.Forms.DataGridView();
            this.colMaPhieu1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTinhTrang1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTraSach1 = new System.Windows.Forms.Button();
            this.errMaDG0 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errMaSach0 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errSLMuon0 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTinhTrang0 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabQLMuonTraSach.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSMuon0)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSMuon1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaDG0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaSach0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLMuon0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang0)).BeginInit();
            this.SuspendLayout();
            // 
            // tabQLMuonTraSach
            // 
            this.tabQLMuonTraSach.Controls.Add(this.tabPage1);
            this.tabQLMuonTraSach.Controls.Add(this.tabPage2);
            this.tabQLMuonTraSach.Location = new System.Drawing.Point(-4, 2);
            this.tabQLMuonTraSach.Name = "tabQLMuonTraSach";
            this.tabQLMuonTraSach.SelectedIndex = 0;
            this.tabQLMuonTraSach.Size = new System.Drawing.Size(777, 585);
            this.tabQLMuonTraSach.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.btnGiaHan);
            this.tabPage1.Controls.Add(this.btnLoadDanhSach0);
            this.tabPage1.Controls.Add(this.btnNhap);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.btnHuy0);
            this.tabPage1.Controls.Add(this.btnThoat0);
            this.tabPage1.Controls.Add(this.btnChoMuon0);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(769, 553);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quản lý Mượn Sách";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(0, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 19);
            this.label21.TabIndex = 10;
            this.label21.Text = "label21";
            // 
            // btnGiaHan
            // 
            this.btnGiaHan.Image = ((System.Drawing.Image)(resources.GetObject("btnGiaHan.Image")));
            this.btnGiaHan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGiaHan.Location = new System.Drawing.Point(403, 301);
            this.btnGiaHan.Name = "btnGiaHan";
            this.btnGiaHan.Size = new System.Drawing.Size(95, 39);
            this.btnGiaHan.TabIndex = 9;
            this.btnGiaHan.Text = "Gia Hạn";
            this.btnGiaHan.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGiaHan.UseVisualStyleBackColor = true;
            this.btnGiaHan.Click += new System.EventHandler(this.btnGiaHan_Click);
            // 
            // btnLoadDanhSach0
            // 
            this.btnLoadDanhSach0.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadDanhSach0.Image")));
            this.btnLoadDanhSach0.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadDanhSach0.Location = new System.Drawing.Point(583, 62);
            this.btnLoadDanhSach0.Name = "btnLoadDanhSach0";
            this.btnLoadDanhSach0.Size = new System.Drawing.Size(146, 39);
            this.btnLoadDanhSach0.TabIndex = 1;
            this.btnLoadDanhSach0.Text = "Load Danh Sách";
            this.btnLoadDanhSach0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadDanhSach0.UseVisualStyleBackColor = true;
            this.btnLoadDanhSach0.Click += new System.EventHandler(this.btnLoadDanhSach0_Click);
            // 
            // btnNhap
            // 
            this.btnNhap.Image = ((System.Drawing.Image)(resources.GetObject("btnNhap.Image")));
            this.btnNhap.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhap.Location = new System.Drawing.Point(172, 301);
            this.btnNhap.Name = "btnNhap";
            this.btnNhap.Size = new System.Drawing.Size(109, 39);
            this.btnNhap.TabIndex = 3;
            this.btnNhap.Text = "Mượn Mới";
            this.btnNhap.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNhap.UseVisualStyleBackColor = true;
            this.btnNhap.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtTTMaSach);
            this.groupBox8.Controls.Add(this.txtTTTenTG);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.txtTTTenSach);
            this.groupBox8.Controls.Add(this.txtTTSLCon);
            this.groupBox8.Location = new System.Drawing.Point(16, 117);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(225, 178);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin Sách";
            // 
            // txtTTMaSach
            // 
            this.txtTTMaSach.Location = new System.Drawing.Point(88, 23);
            this.txtTTMaSach.Name = "txtTTMaSach";
            this.txtTTMaSach.Size = new System.Drawing.Size(128, 27);
            this.txtTTMaSach.TabIndex = 4;
            // 
            // txtTTTenTG
            // 
            this.txtTTTenTG.Location = new System.Drawing.Point(88, 135);
            this.txtTTTenTG.Name = "txtTTTenTG";
            this.txtTTTenTG.Size = new System.Drawing.Size(128, 27);
            this.txtTTTenTG.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tên TG:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Sách  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên Sách:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "SL Còn: ";
            // 
            // txtTTTenSach
            // 
            this.txtTTTenSach.Location = new System.Drawing.Point(88, 59);
            this.txtTTTenSach.Name = "txtTTTenSach";
            this.txtTTTenSach.Size = new System.Drawing.Size(128, 27);
            this.txtTTTenSach.TabIndex = 1;
            // 
            // txtTTSLCon
            // 
            this.txtTTSLCon.Location = new System.Drawing.Point(88, 97);
            this.txtTTSLCon.Name = "txtTTSLCon";
            this.txtTTSLCon.Size = new System.Drawing.Size(128, 27);
            this.txtTTSLCon.TabIndex = 2;
            // 
            // btnHuy0
            // 
            this.btnHuy0.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy0.Image")));
            this.btnHuy0.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy0.Location = new System.Drawing.Point(504, 301);
            this.btnHuy0.Name = "btnHuy0";
            this.btnHuy0.Size = new System.Drawing.Size(85, 39);
            this.btnHuy0.TabIndex = 6;
            this.btnHuy0.Text = "Hủy";
            this.btnHuy0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy0.UseVisualStyleBackColor = true;
            this.btnHuy0.Click += new System.EventHandler(this.btnHuy0_Click);
            // 
            // btnThoat0
            // 
            this.btnThoat0.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnThoat0.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat0.Image")));
            this.btnThoat0.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat0.Location = new System.Drawing.Point(615, 17);
            this.btnThoat0.Name = "btnThoat0";
            this.btnThoat0.Size = new System.Drawing.Size(85, 39);
            this.btnThoat0.TabIndex = 8;
            this.btnThoat0.Text = "Home";
            this.btnThoat0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat0.UseVisualStyleBackColor = false;
            this.btnThoat0.Click += new System.EventHandler(this.btnThoat0_Click);
            // 
            // btnChoMuon0
            // 
            this.btnChoMuon0.Image = ((System.Drawing.Image)(resources.GetObject("btnChoMuon0.Image")));
            this.btnChoMuon0.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChoMuon0.Location = new System.Drawing.Point(287, 301);
            this.btnChoMuon0.Name = "btnChoMuon0";
            this.btnChoMuon0.Size = new System.Drawing.Size(110, 39);
            this.btnChoMuon0.TabIndex = 5;
            this.btnChoMuon0.Text = "Cho mượn";
            this.btnChoMuon0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnChoMuon0.UseVisualStyleBackColor = true;
            this.btnChoMuon0.Click += new System.EventHandler(this.btnChoMuon0_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Location = new System.Drawing.Point(44, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(528, 95);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtNDTimKiem);
            this.groupBox6.Location = new System.Drawing.Point(240, 19);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(271, 60);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Nhập thông tin cần Tìm Kiếm";
            // 
            // txtNDTimKiem
            // 
            this.txtNDTimKiem.Location = new System.Drawing.Point(11, 24);
            this.txtNDTimKiem.Name = "txtNDTimKiem";
            this.txtNDTimKiem.Size = new System.Drawing.Size(249, 27);
            this.txtNDTimKiem.TabIndex = 0;
            this.txtNDTimKiem.TextChanged += new System.EventHandler(this.txtNDTimKiem_TextChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radMaSach);
            this.groupBox7.Controls.Add(this.radMaDG);
            this.groupBox7.Location = new System.Drawing.Point(21, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(190, 60);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tìm Theo";
            // 
            // radMaSach
            // 
            this.radMaSach.AutoSize = true;
            this.radMaSach.Location = new System.Drawing.Point(104, 24);
            this.radMaSach.Name = "radMaSach";
            this.radMaSach.Size = new System.Drawing.Size(88, 23);
            this.radMaSach.TabIndex = 1;
            this.radMaSach.TabStop = true;
            this.radMaSach.Text = "Mã Sách";
            this.radMaSach.UseVisualStyleBackColor = true;
            // 
            // radMaDG
            // 
            this.radMaDG.AutoSize = true;
            this.radMaDG.Location = new System.Drawing.Point(18, 24);
            this.radMaDG.Name = "radMaDG";
            this.radMaDG.Size = new System.Drawing.Size(80, 23);
            this.radMaDG.TabIndex = 0;
            this.radMaDG.TabStop = true;
            this.radMaDG.Text = "Mã ĐG";
            this.radMaDG.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridViewDSMuon0);
            this.groupBox3.Location = new System.Drawing.Point(16, 341);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(736, 206);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách Mượn";
            // 
            // dataGridViewDSMuon0
            // 
            this.dataGridViewDSMuon0.AllowDrop = true;
            this.dataGridViewDSMuon0.AllowUserToAddRows = false;
            this.dataGridViewDSMuon0.AllowUserToDeleteRows = false;
            this.dataGridViewDSMuon0.AllowUserToResizeRows = false;
            this.dataGridViewDSMuon0.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSMuon0.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPhieu,
            this.colMaDG,
            this.colMaSach,
            this.colNgayMuon,
            this.colNgayTra,
            this.colSLMuon,
            this.colTinhTrang,
            this.colGhiChu});
            this.dataGridViewDSMuon0.Location = new System.Drawing.Point(8, 20);
            this.dataGridViewDSMuon0.Name = "dataGridViewDSMuon0";
            this.dataGridViewDSMuon0.ReadOnly = true;
            this.dataGridViewDSMuon0.RowHeadersWidth = 62;
            this.dataGridViewDSMuon0.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSMuon0.Size = new System.Drawing.Size(718, 180);
            this.dataGridViewDSMuon0.TabIndex = 0;
            this.dataGridViewDSMuon0.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSMuon0_RowEnter);
            // 
            // colMaPhieu
            // 
            this.colMaPhieu.DataPropertyName = "MaPhieu";
            this.colMaPhieu.HeaderText = "Mã Phiếu";
            this.colMaPhieu.MinimumWidth = 8;
            this.colMaPhieu.Name = "colMaPhieu";
            this.colMaPhieu.ReadOnly = true;
            this.colMaPhieu.Width = 75;
            // 
            // colMaDG
            // 
            this.colMaDG.DataPropertyName = "MaDG";
            this.colMaDG.HeaderText = "Mã Độc Giả";
            this.colMaDG.MinimumWidth = 8;
            this.colMaDG.Name = "colMaDG";
            this.colMaDG.ReadOnly = true;
            this.colMaDG.Width = 85;
            // 
            // colMaSach
            // 
            this.colMaSach.DataPropertyName = "MaSach";
            this.colMaSach.HeaderText = "Mã Sách";
            this.colMaSach.MinimumWidth = 8;
            this.colMaSach.Name = "colMaSach";
            this.colMaSach.ReadOnly = true;
            this.colMaSach.Width = 75;
            // 
            // colNgayMuon
            // 
            this.colNgayMuon.DataPropertyName = "NgayMuon";
            this.colNgayMuon.HeaderText = "Ngày Mượn";
            this.colNgayMuon.MinimumWidth = 8;
            this.colNgayMuon.Name = "colNgayMuon";
            this.colNgayMuon.ReadOnly = true;
            this.colNgayMuon.Width = 110;
            // 
            // colNgayTra
            // 
            this.colNgayTra.DataPropertyName = "NgayTra";
            this.colNgayTra.HeaderText = "Ngày Trả";
            this.colNgayTra.MinimumWidth = 8;
            this.colNgayTra.Name = "colNgayTra";
            this.colNgayTra.ReadOnly = true;
            this.colNgayTra.Width = 150;
            // 
            // colSLMuon
            // 
            this.colSLMuon.DataPropertyName = "SLMuon";
            this.colSLMuon.HeaderText = "Số Lượng Mượn";
            this.colSLMuon.MinimumWidth = 8;
            this.colSLMuon.Name = "colSLMuon";
            this.colSLMuon.ReadOnly = true;
            this.colSLMuon.Width = 150;
            // 
            // colTinhTrang
            // 
            this.colTinhTrang.DataPropertyName = "TinhTrang";
            this.colTinhTrang.HeaderText = "Tình Trạng";
            this.colTinhTrang.MinimumWidth = 8;
            this.colTinhTrang.Name = "colTinhTrang";
            this.colTinhTrang.ReadOnly = true;
            this.colTinhTrang.Width = 70;
            // 
            // colGhiChu
            // 
            this.colGhiChu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colGhiChu.DataPropertyName = "GhiChu";
            this.colGhiChu.HeaderText = "Ghi Chú";
            this.colGhiChu.MinimumWidth = 8;
            this.colGhiChu.Name = "colGhiChu";
            this.colGhiChu.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboTinhTrang0);
            this.groupBox2.Controls.Add(this.cboMaSach0);
            this.groupBox2.Controls.Add(this.lblNhapSLNhap);
            this.groupBox2.Controls.Add(this.txtMaPhieu0);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.dtmNgayMuon0);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.dtmNgayTra0);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cboMaDG0);
            this.groupBox2.Controls.Add(this.txtSLMuon0);
            this.groupBox2.Controls.Add(this.txtGhiChu0);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(256, 117);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(496, 178);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thực hiện cho Mượn Sách";
            // 
            // cboTinhTrang0
            // 
            this.cboTinhTrang0.FormattingEnabled = true;
            this.cboTinhTrang0.Items.AddRange(new object[] {
            "Mới ",
            "Cũ"});
            this.cboTinhTrang0.Location = new System.Drawing.Point(325, 97);
            this.cboTinhTrang0.Name = "cboTinhTrang0";
            this.cboTinhTrang0.Size = new System.Drawing.Size(150, 27);
            this.cboTinhTrang0.TabIndex = 14;
            this.cboTinhTrang0.SelectedIndexChanged += new System.EventHandler(this.cboTinhTrang0_SelectedIndexChanged);
            // 
            // cboMaSach0
            // 
            this.cboMaSach0.FormattingEnabled = true;
            this.cboMaSach0.Location = new System.Drawing.Point(83, 97);
            this.cboMaSach0.Name = "cboMaSach0";
            this.cboMaSach0.Size = new System.Drawing.Size(128, 27);
            this.cboMaSach0.TabIndex = 13;
            this.cboMaSach0.SelectedIndexChanged += new System.EventHandler(this.cboMaSach0_SelectedIndexChanged);
            // 
            // lblNhapSLNhap
            // 
            this.lblNhapSLNhap.AutoSize = true;
            this.lblNhapSLNhap.Location = new System.Drawing.Point(225, 139);
            this.lblNhapSLNhap.Name = "lblNhapSLNhap";
            this.lblNhapSLNhap.Size = new System.Drawing.Size(0, 19);
            this.lblNhapSLNhap.TabIndex = 12;
            // 
            // txtMaPhieu0
            // 
            this.txtMaPhieu0.Location = new System.Drawing.Point(83, 23);
            this.txtMaPhieu0.Name = "txtMaPhieu0";
            this.txtMaPhieu0.Size = new System.Drawing.Size(128, 27);
            this.txtMaPhieu0.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 19);
            this.label17.TabIndex = 11;
            this.label17.Text = "Mã Phiếu:";
            // 
            // dtmNgayMuon0
            // 
            this.dtmNgayMuon0.CustomFormat = "dd-MM-yyyy";
            this.dtmNgayMuon0.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmNgayMuon0.Location = new System.Drawing.Point(325, 22);
            this.dtmNgayMuon0.Name = "dtmNgayMuon0";
            this.dtmNgayMuon0.ShowUpDown = true;
            this.dtmNgayMuon0.Size = new System.Drawing.Size(148, 27);
            this.dtmNgayMuon0.TabIndex = 4;
            this.dtmNgayMuon0.Value = new System.DateTime(2021, 7, 6, 0, 0, 0, 0);
            this.dtmNgayMuon0.ValueChanged += new System.EventHandler(this.dtmNgayMuon0_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(246, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 19);
            this.label10.TabIndex = 3;
            this.label10.Text = "Ngày Mượn:";
            // 
            // dtmNgayTra0
            // 
            this.dtmNgayTra0.CustomFormat = "dd-MM-yyyy";
            this.dtmNgayTra0.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmNgayTra0.Location = new System.Drawing.Point(325, 63);
            this.dtmNgayTra0.Name = "dtmNgayTra0";
            this.dtmNgayTra0.ShowUpDown = true;
            this.dtmNgayTra0.Size = new System.Drawing.Size(148, 27);
            this.dtmNgayTra0.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(246, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 19);
            this.label9.TabIndex = 3;
            this.label9.Text = "Ngày Trả:";
            // 
            // cboMaDG0
            // 
            this.cboMaDG0.FormattingEnabled = true;
            this.cboMaDG0.Location = new System.Drawing.Point(83, 59);
            this.cboMaDG0.Name = "cboMaDG0";
            this.cboMaDG0.Size = new System.Drawing.Size(128, 27);
            this.cboMaDG0.TabIndex = 1;
            // 
            // txtSLMuon0
            // 
            this.txtSLMuon0.Location = new System.Drawing.Point(83, 134);
            this.txtSLMuon0.MaxLength = 9;
            this.txtSLMuon0.Name = "txtSLMuon0";
            this.txtSLMuon0.Size = new System.Drawing.Size(128, 27);
            this.txtSLMuon0.TabIndex = 3;
            // 
            // txtGhiChu0
            // 
            this.txtGhiChu0.Location = new System.Drawing.Point(327, 134);
            this.txtGhiChu0.Name = "txtGhiChu0";
            this.txtGhiChu0.Size = new System.Drawing.Size(148, 27);
            this.txtGhiChu0.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(248, 103);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 19);
            this.label19.TabIndex = 0;
            this.label19.Text = "Tình Trạng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "SL Mượn: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(248, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Ghi Chú: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mã Sách:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Mã ĐG:  ";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tabPage2.Controls.Add(this.btnLoadDS1);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.btnThoat1);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.btnTraSach1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(769, 553);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Quản lý Trả Sách";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnLoadDS1
            // 
            this.btnLoadDS1.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadDS1.Image")));
            this.btnLoadDS1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadDS1.Location = new System.Drawing.Point(182, 194);
            this.btnLoadDS1.Name = "btnLoadDS1";
            this.btnLoadDS1.Size = new System.Drawing.Size(146, 39);
            this.btnLoadDS1.TabIndex = 6;
            this.btnLoadDS1.Text = "Load Danh Sách";
            this.btnLoadDS1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadDS1.UseVisualStyleBackColor = true;
            this.btnLoadDS1.Click += new System.EventHandler(this.btnLoadDS1_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.groupBox11);
            this.groupBox9.Location = new System.Drawing.Point(16, 16);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(233, 167);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Tìm kiếm";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtNDTimKiem1);
            this.groupBox10.Location = new System.Drawing.Point(10, 91);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(218, 58);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Nhập thông tin cần Tìm Kiếm";
            // 
            // txtNDTimKiem1
            // 
            this.txtNDTimKiem1.Location = new System.Drawing.Point(11, 21);
            this.txtNDTimKiem1.Name = "txtNDTimKiem1";
            this.txtNDTimKiem1.Size = new System.Drawing.Size(198, 27);
            this.txtNDTimKiem1.TabIndex = 0;
            this.txtNDTimKiem1.TextChanged += new System.EventHandler(this.txtNDTimKiem1_TextChanged);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.radMaSach1);
            this.groupBox11.Controls.Add(this.radMaDG1);
            this.groupBox11.Location = new System.Drawing.Point(10, 21);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(182, 53);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Tìm Theo";
            // 
            // radMaSach1
            // 
            this.radMaSach1.AutoSize = true;
            this.radMaSach1.Location = new System.Drawing.Point(99, 23);
            this.radMaSach1.Name = "radMaSach1";
            this.radMaSach1.Size = new System.Drawing.Size(88, 23);
            this.radMaSach1.TabIndex = 1;
            this.radMaSach1.TabStop = true;
            this.radMaSach1.Text = "Mã Sách";
            this.radMaSach1.UseVisualStyleBackColor = true;
            // 
            // radMaDG1
            // 
            this.radMaDG1.AutoSize = true;
            this.radMaDG1.Location = new System.Drawing.Point(13, 23);
            this.radMaDG1.Name = "radMaDG1";
            this.radMaDG1.Size = new System.Drawing.Size(80, 23);
            this.radMaDG1.TabIndex = 0;
            this.radMaDG1.TabStop = true;
            this.radMaDG1.Text = "Mã ĐG";
            this.radMaDG1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtTinhTrang1);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.txtMaDG1);
            this.groupBox5.Controls.Add(this.txtMaPhieu1);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.dtmNgayMuon1);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.dtmNgayTra1);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.txtSLMuon1);
            this.groupBox5.Controls.Add(this.txtGhiChu1);
            this.groupBox5.Controls.Add(this.txtMaSach1);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Location = new System.Drawing.Point(262, 16);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(493, 167);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thực hiện trả sách";
            // 
            // txtTinhTrang1
            // 
            this.txtTinhTrang1.Location = new System.Drawing.Point(339, 94);
            this.txtTinhTrang1.Name = "txtTinhTrang1";
            this.txtTinhTrang1.Size = new System.Drawing.Size(130, 27);
            this.txtTinhTrang1.TabIndex = 16;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(260, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 19);
            this.label20.TabIndex = 15;
            this.label20.Text = "Tình Trạng:";
            // 
            // txtMaDG1
            // 
            this.txtMaDG1.Location = new System.Drawing.Point(95, 57);
            this.txtMaDG1.Name = "txtMaDG1";
            this.txtMaDG1.Size = new System.Drawing.Size(128, 27);
            this.txtMaDG1.TabIndex = 14;
            // 
            // txtMaPhieu1
            // 
            this.txtMaPhieu1.Location = new System.Drawing.Point(95, 22);
            this.txtMaPhieu1.Name = "txtMaPhieu1";
            this.txtMaPhieu1.Size = new System.Drawing.Size(128, 27);
            this.txtMaPhieu1.TabIndex = 12;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 19);
            this.label18.TabIndex = 13;
            this.label18.Text = "Mã Phiếu:";
            // 
            // dtmNgayMuon1
            // 
            this.dtmNgayMuon1.CustomFormat = "dd/MM/yyyy";
            this.dtmNgayMuon1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmNgayMuon1.Location = new System.Drawing.Point(341, 22);
            this.dtmNgayMuon1.Name = "dtmNgayMuon1";
            this.dtmNgayMuon1.Size = new System.Drawing.Size(128, 27);
            this.dtmNgayMuon1.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(260, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 19);
            this.label11.TabIndex = 3;
            this.label11.Text = "Ngày Mượn:";
            // 
            // dtmNgayTra1
            // 
            this.dtmNgayTra1.CustomFormat = "dd/MM/yyyy";
            this.dtmNgayTra1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtmNgayTra1.Location = new System.Drawing.Point(341, 59);
            this.dtmNgayTra1.Name = "dtmNgayTra1";
            this.dtmNgayTra1.Size = new System.Drawing.Size(128, 27);
            this.dtmNgayTra1.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(260, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "Ngày Trả:";
            // 
            // txtSLMuon1
            // 
            this.txtSLMuon1.Location = new System.Drawing.Point(95, 131);
            this.txtSLMuon1.Name = "txtSLMuon1";
            this.txtSLMuon1.Size = new System.Drawing.Size(128, 27);
            this.txtSLMuon1.TabIndex = 2;
            // 
            // txtGhiChu1
            // 
            this.txtGhiChu1.Location = new System.Drawing.Point(342, 133);
            this.txtGhiChu1.Name = "txtGhiChu1";
            this.txtGhiChu1.Size = new System.Drawing.Size(128, 27);
            this.txtGhiChu1.TabIndex = 5;
            // 
            // txtMaSach1
            // 
            this.txtMaSach1.Location = new System.Drawing.Point(95, 94);
            this.txtMaSach1.Name = "txtMaSach1";
            this.txtMaSach1.Size = new System.Drawing.Size(128, 27);
            this.txtMaSach1.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 134);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 19);
            this.label13.TabIndex = 0;
            this.label13.Text = "SL Mượn: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(263, 135);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 19);
            this.label14.TabIndex = 0;
            this.label14.Text = "Ghi Chú: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 97);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 19);
            this.label15.TabIndex = 0;
            this.label15.Text = "Mã Sách:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 19);
            this.label16.TabIndex = 0;
            this.label16.Text = "Mã ĐG:  ";
            // 
            // btnThoat1
            // 
            this.btnThoat1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnThoat1.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat1.Image")));
            this.btnThoat1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat1.Location = new System.Drawing.Point(452, 194);
            this.btnThoat1.Name = "btnThoat1";
            this.btnThoat1.Size = new System.Drawing.Size(97, 39);
            this.btnThoat1.TabIndex = 4;
            this.btnThoat1.Text = "Home";
            this.btnThoat1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat1.UseVisualStyleBackColor = false;
            this.btnThoat1.Click += new System.EventHandler(this.btnThoat1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridViewDSMuon1);
            this.groupBox4.Location = new System.Drawing.Point(16, 232);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(739, 313);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Danh sách Mượn";
            // 
            // dataGridViewDSMuon1
            // 
            this.dataGridViewDSMuon1.AllowUserToAddRows = false;
            this.dataGridViewDSMuon1.AllowUserToDeleteRows = false;
            this.dataGridViewDSMuon1.AllowUserToResizeRows = false;
            this.dataGridViewDSMuon1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSMuon1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPhieu1,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.colTinhTrang1,
            this.dataGridViewTextBoxColumn6});
            this.dataGridViewDSMuon1.Location = new System.Drawing.Point(10, 21);
            this.dataGridViewDSMuon1.Name = "dataGridViewDSMuon1";
            this.dataGridViewDSMuon1.ReadOnly = true;
            this.dataGridViewDSMuon1.RowHeadersWidth = 62;
            this.dataGridViewDSMuon1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSMuon1.Size = new System.Drawing.Size(717, 279);
            this.dataGridViewDSMuon1.TabIndex = 1;
            this.dataGridViewDSMuon1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSMuon1_RowEnter);
            // 
            // colMaPhieu1
            // 
            this.colMaPhieu1.DataPropertyName = "MaPhieu";
            this.colMaPhieu1.HeaderText = "Mã Phiếu";
            this.colMaPhieu1.MinimumWidth = 8;
            this.colMaPhieu1.Name = "colMaPhieu1";
            this.colMaPhieu1.ReadOnly = true;
            this.colMaPhieu1.Width = 75;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MaDG";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã Độc Giả";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 85;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "MaSach";
            this.dataGridViewTextBoxColumn2.HeaderText = "Mã Sách";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 75;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NgayMuon";
            this.dataGridViewTextBoxColumn3.HeaderText = "Ngày Mượn";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 110;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NgayTra";
            this.dataGridViewTextBoxColumn4.HeaderText = "Ngày Trả";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "SLMuon";
            this.dataGridViewTextBoxColumn5.HeaderText = "Số Lượng Mượn";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // colTinhTrang1
            // 
            this.colTinhTrang1.DataPropertyName = "TinhTrang";
            this.colTinhTrang1.HeaderText = "Tình Trạng";
            this.colTinhTrang1.MinimumWidth = 8;
            this.colTinhTrang1.Name = "colTinhTrang1";
            this.colTinhTrang1.ReadOnly = true;
            this.colTinhTrang1.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "GhiChu";
            this.dataGridViewTextBoxColumn6.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // btnTraSach1
            // 
            this.btnTraSach1.Image = ((System.Drawing.Image)(resources.GetObject("btnTraSach1.Image")));
            this.btnTraSach1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTraSach1.Location = new System.Drawing.Point(334, 194);
            this.btnTraSach1.Name = "btnTraSach1";
            this.btnTraSach1.Size = new System.Drawing.Size(98, 39);
            this.btnTraSach1.TabIndex = 2;
            this.btnTraSach1.Text = "Trả Sách";
            this.btnTraSach1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTraSach1.UseVisualStyleBackColor = true;
            this.btnTraSach1.Click += new System.EventHandler(this.btnTraSach1_Click);
            // 
            // errMaDG0
            // 
            this.errMaDG0.ContainerControl = this;
            // 
            // errMaSach0
            // 
            this.errMaSach0.ContainerControl = this;
            // 
            // errSLMuon0
            // 
            this.errSLMuon0.ContainerControl = this;
            // 
            // errTinhTrang0
            // 
            this.errTinhTrang0.ContainerControl = this;
            // 
            // frmQLMuonTra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(767, 583);
            this.Controls.Add(this.tabQLMuonTraSach);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmQLMuonTra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Mượn - Trả";
            this.Load += new System.EventHandler(this.frmQLMuonTra_Load);
            this.tabQLMuonTraSach.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSMuon0)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSMuon1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaDG0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaSach0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLMuon0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang0)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabQLMuonTraSach;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnThoat0;
        private System.Windows.Forms.Button btnHuy0;
        private System.Windows.Forms.Button btnChoMuon0;
        private System.Windows.Forms.DateTimePicker dtmNgayMuon0;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtmNgayTra0;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboMaDG0;
        private System.Windows.Forms.TextBox txtSLMuon0;
        private System.Windows.Forms.TextBox txtGhiChu0;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnThoat1;
        private System.Windows.Forms.Button btnTraSach1;
        private System.Windows.Forms.DateTimePicker dtmNgayMuon1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtmNgayTra1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSLMuon1;
        private System.Windows.Forms.TextBox txtGhiChu1;
        private System.Windows.Forms.TextBox txtMaSach1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView dataGridViewDSMuon0;
        private System.Windows.Forms.DataGridView dataGridViewDSMuon1;
        private System.Windows.Forms.Button btnNhap;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtNDTimKiem;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radMaSach;
        private System.Windows.Forms.RadioButton radMaDG;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtTTTenTG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTTTenSach;
        private System.Windows.Forms.TextBox txtTTSLCon;
        private System.Windows.Forms.Button btnLoadDanhSach0;
        private System.Windows.Forms.TextBox txtMaPhieu0;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblNhapSLNhap;
        private System.Windows.Forms.Button btnGiaHan;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtNDTimKiem1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radMaSach1;
        private System.Windows.Forms.RadioButton radMaDG1;
        private System.Windows.Forms.TextBox txtMaPhieu1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnLoadDS1;
        private System.Windows.Forms.ComboBox cboMaSach0;
        private System.Windows.Forms.TextBox txtTTMaSach;
        private System.Windows.Forms.TextBox txtMaDG1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaDG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayMuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayTra;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSLMuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTinhTrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGhiChu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaPhieu1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTinhTrang1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TextBox txtTinhTrang1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ErrorProvider errMaDG0;
        private System.Windows.Forms.ErrorProvider errMaSach0;
        private System.Windows.Forms.ErrorProvider errSLMuon0;
        private System.Windows.Forms.ComboBox cboTinhTrang0;
        private System.Windows.Forms.ErrorProvider errTinhTrang0;
        private System.Windows.Forms.Label label21;
    }
}